Files deployed at paradigmchess30.epizy.com 
